
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JPanel;
import javax.swing.JOptionPane;

public class Reconocedor extends javax.swing.JFrame implements ActionListener{
       public static void main (String[] args){
         Reconocedor r = new Reconocedor();
         r.setVisible(true);
       }

JLabel etiHileraProbar;
JTextField txtHileraProbar;
JButton probar;
JPanel panel;
private String simbolos;
private char simbolo;
private short i;

       public Reconocedor(){
         this.setLocationRelativeTo(null);
         this.setResizable(false);
         this.setTitle("Reconocedor de hileras");
         this.setDefaultCloseOperation(Reconocedor.EXIT_ON_CLOSE);
         etiHileraProbar = new JLabel("Ingrese hilera a probar:");
         etiHileraProbar.setBounds(10,20,150,20);
         txtHileraProbar = new JTextField();
         txtHileraProbar.setBounds(160,20,100,20);
         probar =  new JButton("Probar hilera"); 
         probar.setBounds(270,20,150,20);
         probar.addActionListener(this);
         panel = new JPanel();
         panel.setLayout(null);
         panel.add(etiHileraProbar);
         panel.add(txtHileraProbar);
         panel.add(probar);
         add(panel);
         setSize(500,100);
         setVisible(true);
       }
@Override
     public void actionPerformed(ActionEvent e){
         if (e.getSource()==probar){
             simbolos = txtHileraProbar.getText() + "?";
             i = 1;
             principal();
         }
      }
     public void principal(){
         String especial = "?";        simbolo = simbolos.charAt(0);
        ntS();
        if(simbolo==especial.charAt(0)){
            JOptionPane.showMessageDialog(null, "La hilera es aceptada","Reconocimiento de hilera",JOptionPane.PLAIN_MESSAGE);
        }
        else{
            JOptionPane.showMessageDialog(null, "La hilera es rechazada","Reconocimiento de hilera",JOptionPane.PLAIN_MESSAGE);
        }
    }

    public void ntS(){
	switch(simbolo){
            case 'b':
                simbolo = simbolos.charAt(i);
                i++;
                ntC();
                ntA();
                ntC();
                if(simbolo=='d'){
                    simbolo = simbolos.charAt(i);
                    i++;
                    break;
                }
                simbolo = ' ';
                break;
	    default:
	        simbolo = ' ';
	}
    }

    public void ntA(){
	switch(simbolo){
            case 'd':
                simbolo = simbolos.charAt(i);
                i++;
                ntC();
                ntC();
                break;
	    default:
	        simbolo = ' ';
	}
    }

    public void ntC(){
	switch(simbolo){
            case 'c':
                simbolo = simbolos.charAt(i);
                i++;
                ntS();
                break;
            case 'd':
                simbolo = simbolos.charAt(i);
                i++;
                break;
	    default:
	        simbolo = ' ';
	}
    }

}